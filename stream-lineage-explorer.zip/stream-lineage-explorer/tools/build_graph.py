#!/usr/bin/env python3
"""
Build graph.json for Stream Lineage Explorer.

Joins two exports into the graph the page renders:

  * an IaC export (what is DECLARED): clusters, apps, principals, topics,
    role bindings, connectors, cluster links, replicators
  * a metrics export (what is OBSERVED): produce/consume activity per
    principal, consumer-group lag, mirror and replicator throughput,
    connector throughput

Every edge in the output carries both sides, so the page can tell
"declared and active", "declared but idle" and "observed but undeclared"
apart. See docs/INTEGRATION.md for the input formats and docs/DATA_MODEL.md
for the output format.

Usage:
  python3 tools/build_graph.py \
      --iac tools/examples/iac_export.json \
      --metrics tools/examples/metrics_export.json \
      --out data/graph.json --js-out data/graph.js

Only the Python standard library is used.
"""
import argparse
import datetime as dt
import json
import sys
from collections import defaultdict

SCHEMA_VERSION = 1
WRITE_ROLES = {"DeveloperWrite", "ResourceOwner"}
READ_ROLES = {"DeveloperRead", "ResourceOwner"}
PRINCIPAL_KIND_LABEL = {
    "service-account": "Service account",
    "identity-pool": "Identity pool",
    "cp-principal": "CP principal",
    "user": "User account",
}


def topic_id(cluster, name):
    return f"topic:{cluster}:{name}"


def binding_matches(binding, resource_type, name):
    """True if a role binding covers the named resource (LITERAL or PREFIXED)."""
    if binding.get("resourceType") != resource_type:
        return False
    pattern = binding.get("patternType", "LITERAL").upper()
    if pattern == "PREFIXED":
        return name.startswith(binding["resourceName"])
    return name == binding["resourceName"]


def describe_binding(b):
    prefix = "*" if b.get("patternType", "LITERAL").upper() == "PREFIXED" else ""
    return {
        "principal": b["principal"],
        "role": b["role"],
        "resource": f'{b["resourceType"]}:{b["resourceName"]}{prefix}',
        "source": b.get("iacSource", ""),
    }


class GraphBuilder:
    def __init__(self, iac, metrics, args):
        self.iac = iac
        self.metrics = metrics
        self.args = args
        self.warnings = []
        self.clusters = {c["id"]: c for c in iac.get("clusters", [])}
        self.apps = {a["code"]: dict(a, principals=[]) for a in iac.get("apps", [])}
        self.principal_app = {}
        for p in iac.get("principals", []):
            if p["app"] not in self.apps:
                self.warn(f'principal {p["id"]} belongs to unknown app {p["app"]}')
                continue
            self.principal_app[p["id"]] = p["app"]
            self.apps[p["app"]]["principals"].append({
                "id": p["id"],
                "kind": PRINCIPAL_KIND_LABEL.get(p.get("kind", ""), p.get("kind", "Principal")),
                "detail": p.get("detail", ""),
            })
        self.connector_principals = {c["principal"] for c in iac.get("connectors", []) if c.get("principal")}
        self.bindings_by_principal = defaultdict(list)
        for b in iac.get("roleBindings", []):
            self.bindings_by_principal[b["principal"]].append(b)
        self.avg_bytes = {(s["cluster"], s["topic"]): s.get("avgRecordBytes") for s in metrics.get("topicStats", [])}
        self.topics = {}
        for t in iac.get("topics", []):
            self.add_topic(t["cluster"], t["name"], t)
        self.edges = {}
        self.unmanaged = set()

    # ------------------------------------------------------------ helpers
    def warn(self, msg):
        self.warnings.append(msg)

    def add_topic(self, cluster, name, spec=None, unmanaged=False):
        key = topic_id(cluster, name)
        if key in self.topics:
            return key
        if cluster not in self.clusters:
            self.warn(f"topic {name} references unknown cluster {cluster}")
        spec = spec or {}
        topic = {"cluster": cluster, "name": name}
        for field in ("partitions", "retention", "schema", "iacSource"):
            if spec.get(field) is not None:
                topic[field] = spec[field]
        if self.avg_bytes.get((cluster, name)):
            topic["avgBytes"] = self.avg_bytes[(cluster, name)]
        if unmanaged:
            topic["unmanaged"] = True
        self.topics[key] = topic
        return key

    def edge(self, kind, src, dst, **fields):
        key = (kind, src, dst)
        if key not in self.edges:
            self.edges[key] = {"kind": kind, "from": src, "to": dst, "declared": False}
        e = self.edges[key]
        for k, v in fields.items():
            if v is None:
                continue
            if k == "bindings":
                existing = e.setdefault("bindings", [])
                for b in v:
                    if b not in existing:
                        existing.append(b)
            elif k == "declared":
                e["declared"] = e["declared"] or v
            else:
                e[k] = v
        return e

    def observe(self, e, rate=None, lag=None, seen=None, principal=None, state=None):
        """Merge an observation into an edge (several records may hit one edge)."""
        o = e.setdefault("observed", {})
        if seen is not None:
            o["lastSeenHoursAgo"] = min(seen, o.get("lastSeenHoursAgo", seen))
        if rate is not None:
            o["rateMsgs"] = round(o.get("rateMsgs", 0) + rate, 3)
        if lag is not None:
            o["lag"] = max(lag, o.get("lag") or 0)
        if principal and "principal" not in o:
            o["principal"] = principal
        if state:
            o["state"] = state

    def app_for_principal(self, principal):
        return self.principal_app.get(principal)

    def app_for_group(self, cluster, group):
        """Resolve a consumer group to an app via Group role bindings."""
        hits = set()
        for principal, bindings in self.bindings_by_principal.items():
            for b in bindings:
                if b.get("cluster") == cluster and b["role"] in READ_ROLES and binding_matches(b, "Group", group):
                    app = self.principal_app.get(principal)
                    if app:
                        hits.add(app)
        if len(hits) > 1:
            self.warn(f"consumer group {group} on {cluster} matches several apps: {sorted(hits)}")
        return sorted(hits)[0] if hits else None

    def unmanaged_app(self, principal, group=None):
        code = principal or f"group:{group}"
        if code not in self.apps:
            self.apps[code] = {
                "code": code,
                "name": "Unmanaged principal",
                "team": "Not in IaC",
                "iacPath": "",
                "unmanaged": True,
                "principals": [{"id": principal or "(unknown)", "kind": "Unknown principal",
                                "detail": "Seen in metrics only" + (f", group {group}" if group else "")}],
            }
            self.unmanaged.add(code)
        return code

    def group_bindings(self, app, cluster, group):
        out = []
        for p in self.apps.get(app, {}).get("principals", []):
            for b in self.bindings_by_principal.get(p["id"], []):
                if b.get("cluster") == cluster and b["role"] in READ_ROLES and binding_matches(b, "Group", group):
                    out.append(describe_binding(b))
        return out

    # ------------------------------------------------------------ steps
    def declared_client_edges(self):
        topics_by_cluster = defaultdict(list)
        for key, t in self.topics.items():
            topics_by_cluster[t["cluster"]].append(t["name"])
        for principal, bindings in self.bindings_by_principal.items():
            app = self.app_for_principal(principal)
            if not app:
                self.warn(f"role bindings for principal {principal} which is not mapped to an app")
                continue
            if principal in self.connector_principals:
                continue
            for b in bindings:
                if b.get("resourceType") != "Topic":
                    continue
                for name in topics_by_cluster.get(b.get("cluster"), []):
                    if not binding_matches(b, "Topic", name):
                        continue
                    tid = topic_id(b["cluster"], name)
                    if b["role"] in WRITE_ROLES:
                        self.edge("produce", f"app:{app}", tid, declared=True, bindings=[describe_binding(b)])
                    if b["role"] in READ_ROLES:
                        self.edge("consume", tid, f"app:{app}", declared=True, bindings=[describe_binding(b)])

    def observed_client_edges(self):
        for r in self.metrics.get("produce", []):
            if r.get("principal") in self.connector_principals:
                continue
            app = self.app_for_principal(r.get("principal")) or self.unmanaged_app(r.get("principal"))
            tid = self.add_topic(r["cluster"], r["topic"], unmanaged=topic_id(r["cluster"], r["topic"]) not in self.topics)
            e = self.edge("produce", f"app:{app}", tid)
            self.observe(e, r.get("rateMsgs"), None, r.get("lastSeenHoursAgo"), r.get("principal"))

        groups_seen = defaultdict(list)
        for r in self.metrics.get("consume", []):
            if r.get("principal") in self.connector_principals:
                continue
            group = r.get("group")
            app = (self.app_for_principal(r.get("principal"))
                   or (self.app_for_group(r["cluster"], group) if group else None)
                   or self.unmanaged_app(r.get("principal"), group))
            tid = self.add_topic(r["cluster"], r["topic"], unmanaged=topic_id(r["cluster"], r["topic"]) not in self.topics)
            e = self.edge("consume", tid, f"app:{app}")
            self.observe(e, r.get("rateMsgs"), r.get("lag"), r.get("lastSeenHoursAgo"), r.get("principal"))
            if group:
                groups_seen[(tid, app)].append(group)
                if e["declared"]:
                    gb = self.group_bindings(app, r["cluster"], group)
                    if gb:
                        self.edge("consume", tid, f"app:{app}", bindings=gb)
                    else:
                        self.warn(f"{app} reads {tid} with group {group} but has no Group binding covering it")
        for (tid, app), groups in groups_seen.items():
            self.edges[("consume", tid, f"app:{app}")]["group"] = ", ".join(sorted(set(groups)))

        # Declared consumers that never showed up in metrics: name the group if it's unambiguous.
        for (kind, src, dst), e in self.edges.items():
            if kind != "consume" or "group" in e:
                continue
            app = dst.split(":", 1)[1]
            cluster = self.topics[src]["cluster"] if src in self.topics else None
            literal = [b for p in self.apps.get(app, {}).get("principals", [])
                       for b in self.bindings_by_principal.get(p["id"], [])
                       if b.get("resourceType") == "Group" and b.get("cluster") == cluster
                       and b.get("patternType", "LITERAL").upper() == "LITERAL"]
            if len(literal) == 1:
                e["group"] = literal[0]["resourceName"]

    def cluster_links(self):
        mirror_metrics = {(m["link"], m["topic"]): m for m in self.metrics.get("mirrors", [])}
        self.links = []
        for L in self.iac.get("clusterLinks", []):
            self.links.append({k: L[k] for k in ("name", "sourceCluster", "destinationCluster", "owner", "iacSource") if k in L})
            lid = f'link:{L["name"]}'
            for t in L.get("mirrorTopics", []):
                src = self.add_topic(L["sourceCluster"], t)
                dst = self.add_topic(L["destinationCluster"], t)
                src_spec = self.topics[src]
                for field in ("partitions", "schema"):
                    if field in src_spec and field not in self.topics[dst]:
                        self.topics[dst][field] = src_spec[field]
                e_in = self.edge("link-in", src, lid, declared=True, iacSource=L.get("iacSource"))
                e_out = self.edge("link-out", lid, dst, declared=True, iacSource=L.get("iacSource"), mirrorOf=src)
                m = mirror_metrics.get((L["name"], t))
                if m:
                    for e in (e_in, e_out):
                        self.observe(e, m.get("rateMsgs"), m.get("lag"), m.get("lastSeenHoursAgo"), None, m.get("state"))
                else:
                    self.warn(f'no mirror metrics for {t} on link {L["name"]}')

    def replicators(self):
        rep_metrics = {(m["name"], m["sourceTopic"]): m for m in self.metrics.get("replicators", [])}
        self.reps = []
        for R in self.iac.get("replicators", []):
            self.reps.append({k: R[k] for k in ("name", "sourceCluster", "destinationCluster", "host", "renameRule", "owner", "iacSource") if k in R})
            rid = f'rep:{R["name"]}'
            for pair in R.get("topics", []):
                src = self.add_topic(R["sourceCluster"], pair["source"])
                dst = self.add_topic(R["destinationCluster"], pair["destination"])
                e_in = self.edge("rep-in", src, rid, declared=True, iacSource=R.get("iacSource"))
                e_out = self.edge("rep-out", rid, dst, declared=True, iacSource=R.get("iacSource"), mirrorOf=src)
                m = rep_metrics.get((R["name"], pair["source"]))
                if m:
                    for e in (e_in, e_out):
                        self.observe(e, m.get("rateMsgs"), m.get("lag"), m.get("lastSeenHoursAgo"))

    def connectors(self):
        cm = {m["name"]: m for m in self.metrics.get("connectors", [])}
        self.conns = []
        for C in self.iac.get("connectors", []):
            if C["app"] not in self.apps:
                self.warn(f'connector {C["name"]} owned by unknown app {C["app"]}')
                continue
            self.conns.append({"name": C["name"], "cluster": C["cluster"], "owner": C["app"], "class": C.get("class", ""),
                               "direction": C["direction"], "tasks": C.get("tasks", 1), "iacSource": C.get("iacSource", "")})
            cid, app = f'conn:{C["name"]}', f'app:{C["app"]}'
            m = cm.get(C["name"], {})
            per_topic = {t["topic"]: t for t in m.get("topics", [])}
            seen = m.get("lastSeenHoursAgo")
            state = f'{m["status"]}, {m.get("tasksRunning", "?")}/{C.get("tasks", "?")} tasks' if m.get("status") else None
            if C["direction"] == "sink":
                for t in C.get("topics", []):
                    tid = self.add_topic(C["cluster"], t)
                    e = self.edge("sink-in", tid, cid, declared=True, iacSource=C.get("iacSource"),
                                  group=f'{self.args.connect_group_prefix}{C["name"]}')
                    if m:
                        pt = per_topic.get(t, {})
                        self.observe(e, pt.get("rateMsgs"), pt.get("lag"), seen, None, state)
                e = self.edge("sink-out", cid, app, declared=True, iacSource=C.get("iacSource"))
                if m:
                    self.observe(e, m.get("rateMsgs"), None, seen, None, state)
            else:
                e = self.edge("source-in", app, cid, declared=True, iacSource=C.get("iacSource"))
                if m:
                    self.observe(e, m.get("rateMsgs"), None, seen, None, state)
                for t in C.get("topics", []):
                    tid = self.add_topic(C["cluster"], t)
                    e = self.edge("source-out", cid, tid, declared=True, iacSource=C.get("iacSource"))
                    if m:
                        pt = per_topic.get(t, {})
                        self.observe(e, pt.get("rateMsgs"), pt.get("lag"), seen, None, state)

    # ------------------------------------------------------------ output
    def build(self):
        self.declared_client_edges()
        self.observed_client_edges()
        self.cluster_links()
        self.replicators()
        self.connectors()
        apps = sorted(self.apps.values(), key=lambda a: (a.get("unmanaged", False), a["code"]))
        focus = self.args.default_focus or (f'app:{apps[0]["code"]}' if apps else None)
        graph = {
            "schemaVersion": SCHEMA_VERSION,
            "generatedAt": self.metrics.get("collectedAt") or dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "sources": {
                "iac": self.iac.get("exportedFrom", ""),
                "iacExportedAt": self.iac.get("exportedAt", ""),
                "metrics": self.metrics.get("collectedFrom", ""),
                "metricsLookbackHours": self.metrics.get("lookbackHours"),
            },
            "settings": {
                "title": self.args.title,
                "lagThreshold": self.args.lag_threshold,
                "windows": self.args.windows,
                "defaultWindow": self.args.default_window,
                "defaultView": self.args.default_view,
                "defaultFocus": focus,
                "defaultUpstream": self.args.default_depth,
                "defaultDownstream": self.args.default_depth,
            },
            "clusters": list(self.clusters.values()),
            "apps": apps,
            "topics": sorted(self.topics.values(), key=lambda t: (t["cluster"], t["name"])),
            "connectors": self.conns,
            "clusterLinks": self.links,
            "replicators": self.reps,
            "edges": list(self.edges.values()),
        }
        return graph


def summary(graph, builder):
    edges = graph["edges"]
    drift = [e for e in edges if not e["declared"]]
    never = [e for e in edges if e["declared"] and not e.get("observed")]
    lines = [
        f'clusters {len(graph["clusters"])}, apps {len(graph["apps"])}, topics {len(graph["topics"])}, '
        f'connectors {len(graph["connectors"])}, links {len(graph["clusterLinks"])}, replicators {len(graph["replicators"])}, edges {len(edges)}',
        f"undeclared (drift) edges: {len(drift)}",
    ]
    lines += [f'  {e["kind"]:8} {e["from"]} -> {e["to"]}' for e in drift]
    lines.append(f"declared edges never observed: {len(never)}")
    lines += [f'  {e["kind"]:8} {e["from"]} -> {e["to"]}' for e in never]
    if builder.unmanaged:
        lines.append(f"unmanaged principals: {', '.join(sorted(builder.unmanaged))}")
    if builder.warnings:
        lines.append(f"warnings: {len(builder.warnings)}")
        lines += [f"  {w}" for w in builder.warnings]
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--iac", required=True, help="IaC export JSON (see docs/INTEGRATION.md)")
    ap.add_argument("--metrics", required=True, help="metrics export JSON (see docs/INTEGRATION.md)")
    ap.add_argument("--out", default="data/graph.json", help="where to write graph.json")
    ap.add_argument("--js-out", default=None, help="also write a graph.js wrapper so the page works from file://")
    ap.add_argument("--title", default="Stream lineage")
    ap.add_argument("--lag-threshold", type=int, default=10000, help="consumer lag (messages) above which a flow is 'lagging'")
    ap.add_argument("--windows", type=lambda s: [int(x) for x in s.split(",")], default=[24, 168, 720],
                    help="activity windows in hours, comma separated")
    ap.add_argument("--default-window", type=int, default=168)
    ap.add_argument("--default-view", choices=["app", "detail"], default="app")
    ap.add_argument("--default-focus", default=None, help="entity id to open on, e.g. app:ORD")
    ap.add_argument("--default-depth", type=int, default=3)
    ap.add_argument("--connect-group-prefix", default="connect-",
                    help="consumer group prefix used by sink connectors (Confluent Cloud managed connectors use connect-lcc-...)")
    args = ap.parse_args(argv)
    if args.default_window not in args.windows:
        ap.error("--default-window must be one of --windows")

    with open(args.iac) as f:
        iac = json.load(f)
    with open(args.metrics) as f:
        metrics = json.load(f)
    builder = GraphBuilder(iac, metrics, args)
    graph = builder.build()

    with open(args.out, "w") as f:
        json.dump(graph, f, indent=2)
    if args.js_out:
        with open(args.js_out, "w") as f:
            f.write("/* Generated by tools/build_graph.py. Lets index.html load the graph from file://. */\n")
            f.write("window.LINEAGE_DATA = ")
            json.dump(graph, f, separators=(",", ":"))
            f.write(";\n")
    print(summary(graph, builder), file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
