#!/usr/bin/env python3
"""
Validate a graph.json before publishing it.

Checks, in order:
  1. JSON Schema (schema/graph.schema.json), if the `jsonschema` package is
     installed. Skipped with a notice otherwise.
  2. Referential integrity: every edge endpoint exists, IDs are unique,
     connector owners and cluster references resolve.
  3. Semantics: each edge kind joins the right entity types, link-out and
     rep-out edges carry mirrorOf and a matching *-in edge, settings point
     at real entities.

Exit code 0 when there are no errors (warnings are allowed), 1 otherwise.

Usage:
  python3 tools/validate_graph.py data/graph.json
"""
import json
import os
import sys

KIND_TYPES = {
    "produce": ("app", "topic"),
    "consume": ("topic", "app"),
    "link-in": ("topic", "link"),
    "link-out": ("link", "topic"),
    "rep-in": ("topic", "rep"),
    "rep-out": ("rep", "topic"),
    "sink-in": ("topic", "conn"),
    "sink-out": ("conn", "app"),
    "source-in": ("app", "conn"),
    "source-out": ("conn", "topic"),
}


def main(path):
    errors, warnings = [], []
    with open(path) as f:
        g = json.load(f)

    schema_path = os.path.join(os.path.dirname(__file__), "..", "schema", "graph.schema.json")
    try:
        import jsonschema  # type: ignore
        with open(schema_path) as f:
            schema = json.load(f)
        for err in jsonschema.Draft202012Validator(schema).iter_errors(g):
            loc = "/".join(str(p) for p in err.absolute_path)
            errors.append(f"schema: {loc or '(root)'}: {err.message}")
    except ImportError:
        print("note: jsonschema not installed, skipping schema check (pip install jsonschema)", file=sys.stderr)

    ids = {}

    def reg(eid, kind):
        if eid in ids:
            errors.append(f"duplicate entity id {eid}")
        ids[eid] = kind

    clusters = {c.get("id") for c in g.get("clusters", [])}
    if len(clusters) != len(g.get("clusters", [])):
        errors.append("duplicate cluster ids")
    for a in g.get("apps", []):
        reg(f'app:{a.get("code")}', "app")
    for t in g.get("topics", []):
        if t.get("cluster") not in clusters:
            errors.append(f'topic {t.get("name")} references unknown cluster {t.get("cluster")}')
        reg(f'topic:{t.get("cluster")}:{t.get("name")}', "topic")
    for c in g.get("connectors", []):
        reg(f'conn:{c.get("name")}', "conn")
        if c.get("cluster") not in clusters:
            errors.append(f'connector {c.get("name")} references unknown cluster {c.get("cluster")}')
        if f'app:{c.get("owner")}' not in ids:
            errors.append(f'connector {c.get("name")} owner {c.get("owner")} is not an app')
    for L in g.get("clusterLinks", []):
        reg(f'link:{L.get("name")}', "link")
        for k in ("sourceCluster", "destinationCluster"):
            if L.get(k) not in clusters:
                errors.append(f'cluster link {L.get("name")} {k} {L.get(k)} is not a cluster')
    for R in g.get("replicators", []):
        reg(f'rep:{R.get("name")}', "rep")
        for k in ("sourceCluster", "destinationCluster"):
            if R.get(k) not in clusters:
                errors.append(f'replicator {R.get("name")} {k} {R.get(k)} is not a cluster')

    seen_edges = set()
    in_edges = set()
    for i, e in enumerate(g.get("edges", [])):
        kind, src, dst = e.get("kind"), e.get("from"), e.get("to")
        where = f"edge[{i}] {kind} {src} -> {dst}"
        if kind not in KIND_TYPES:
            errors.append(f"{where}: unknown kind")
            continue
        for end, want in zip((src, dst), KIND_TYPES[kind]):
            if end not in ids:
                errors.append(f"{where}: {end} does not exist")
            elif ids[end] != want:
                errors.append(f"{where}: {end} is a {ids[end]}, expected a {want}")
        key = (kind, src, dst)
        if key in seen_edges:
            errors.append(f"{where}: duplicate edge")
        seen_edges.add(key)
        if kind in ("link-in", "rep-in"):
            in_edges.add((src, dst))
        o = e.get("observed")
        if not e.get("declared") and not o:
            errors.append(f"{where}: undeclared edge with no observation (nothing supports it)")
        if o:
            for fld in ("lastSeenHoursAgo", "rateMsgs", "lag"):
                v = o.get(fld)
                if v is not None and (not isinstance(v, (int, float)) or v < 0):
                    errors.append(f"{where}: observed.{fld} must be a non-negative number")
        if kind in ("consume", "sink-in") and not e.get("group"):
            warnings.append(f"{where}: no consumer group")

    for i, e in enumerate(g.get("edges", [])):
        if e.get("kind") in ("link-out", "rep-out"):
            where = f'edge[{i}] {e["kind"]} {e.get("from")} -> {e.get("to")}'
            mo = e.get("mirrorOf")
            if not mo:
                errors.append(f"{where}: mirrorOf is required")
            elif (mo, e.get("from")) not in in_edges:
                errors.append(f"{where}: mirrorOf {mo} has no matching {e['kind'][:-4]}-in edge into {e.get('from')}")

    s = g.get("settings", {})
    if s.get("defaultFocus") and s["defaultFocus"] not in ids:
        errors.append(f'settings.defaultFocus {s["defaultFocus"]} does not exist')
    if s.get("defaultView") == "app" and s.get("defaultFocus", "app:").split(":")[0] != "app":
        warnings.append("settings.defaultFocus is not an app but defaultView is app; the page will pick the nearest app")
    if s.get("windows") and s.get("defaultWindow") and s["defaultWindow"] not in s["windows"]:
        errors.append("settings.defaultWindow is not one of settings.windows")

    connected = {x for e in g.get("edges", []) for x in (e.get("from"), e.get("to"))}
    for eid, kind in ids.items():
        if eid not in connected:
            warnings.append(f"{eid} has no edges (it will only be reachable through search)")

    for w in warnings:
        print(f"warning: {w}")
    for er in errors:
        print(f"error: {er}")
    print(f"{path}: {len(ids)} entities, {len(g.get('edges', []))} edges, {len(errors)} errors, {len(warnings)} warnings")
    return 1 if errors else 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
