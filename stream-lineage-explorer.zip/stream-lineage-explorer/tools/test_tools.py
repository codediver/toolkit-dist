#!/usr/bin/env python3
"""Tests for build_graph.py and validate_graph.py. Run: python3 -m unittest tools/test_tools.py"""
import copy
import io
import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_graph  # noqa: E402
import validate_graph  # noqa: E402

EXAMPLES = os.path.join(HERE, "examples")


def load(name):
    with open(os.path.join(EXAMPLES, name)) as f:
        return json.load(f)


def build(iac=None, metrics=None, extra_args=()):
    iac = iac if iac is not None else load("iac_export.json")
    metrics = metrics if metrics is not None else load("metrics_export.json")
    with tempfile.TemporaryDirectory() as d:
        ip, mp, op = (os.path.join(d, n) for n in ("iac.json", "m.json", "g.json"))
        json.dump(iac, open(ip, "w"))
        json.dump(metrics, open(mp, "w"))
        with redirect_stderr(io.StringIO()):
            build_graph.main(["--iac", ip, "--metrics", mp, "--out", op, *extra_args])
        return json.load(open(op))


def edges(g, kind=None):
    return {(e["kind"], e["from"], e["to"]): e for e in g["edges"] if kind is None or e["kind"] == kind}


class BuildGraphTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.g = build()

    def test_counts(self):
        self.assertEqual(len(self.g["clusters"]), 4)
        self.assertEqual(len(self.g["edges"]), 50)

    def test_declared_and_observed_produce(self):
        e = edges(self.g)[("produce", "app:ORD", "topic:east:orders.v1")]
        self.assertTrue(e["declared"])
        self.assertEqual(e["observed"]["rateMsgs"], 380)
        self.assertEqual(e["bindings"][0]["role"], "DeveloperWrite")

    def test_drift_consumer_is_undeclared(self):
        e = edges(self.g)[("consume", "topic:east:payments.v1", "app:ANL")]
        self.assertFalse(e["declared"])
        self.assertEqual(e["group"], "anl-adhoc-notebook")

    def test_idle_grant_keeps_last_seen(self):
        e = edges(self.g)[("consume", "topic:east:orders.v1", "app:AUD")]
        self.assertTrue(e["declared"])
        self.assertEqual(e["observed"]["lastSeenHoursAgo"], 400)

    def test_unmanaged_principal_becomes_app(self):
        apps = {a["code"]: a for a in self.g["apps"]}
        self.assertTrue(apps["sa-0ld42x"]["unmanaged"])

    def test_prefixed_group_binding_attached(self):
        e = edges(self.g)[("consume", "topic:east:orders.v1", "app:PAY")]
        self.assertIn("Group:pay-*", [b["resource"] for b in e["bindings"]])

    def test_link_edges_carry_mirror_of(self):
        e = edges(self.g)[("link-out", "link:cl-east-analytics", "topic:analytics:orders.v1")]
        self.assertEqual(e["mirrorOf"], "topic:east:orders.v1")
        self.assertEqual(e["observed"]["state"], "ACTIVE")

    def test_connector_principals_do_not_create_app_edges(self):
        m = load("metrics_export.json")
        m["produce"].append({"cluster": "analytics", "topic": "dwh.daily-agg", "principal": "sa-dwhconn1", "rateMsgs": 12, "lastSeenHoursAgo": 0})
        g = build(metrics=m)
        self.assertNotIn(("produce", "app:DWH", "topic:analytics:dwh.daily-agg"), edges(g))

    def test_group_resolves_app_when_principal_unknown(self):
        m = load("metrics_export.json")
        m["consume"].append({"cluster": "east", "topic": "orders.v1", "group": "pay-reconciler", "principal": None,
                             "rateMsgs": 5, "lag": 0, "lastSeenHoursAgo": 1})
        g = build(metrics=m)
        self.assertIn("pay-reconciler", edges(g)[("consume", "topic:east:orders.v1", "app:PAY")]["group"])

    def test_unknown_topic_is_flagged(self):
        m = load("metrics_export.json")
        m["produce"].append({"cluster": "east", "topic": "tmp.debug", "principal": "sa-1a2b3c", "rateMsgs": 1, "lastSeenHoursAgo": 3})
        g = build(metrics=m)
        topics = {(t["cluster"], t["name"]): t for t in g["topics"]}
        self.assertTrue(topics[("east", "tmp.debug")]["unmanaged"])

    def test_output_validates(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(self.g, f)
        try:
            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(validate_graph.main(f.name), 0)
        finally:
            os.unlink(f.name)


class ValidateGraphTests(unittest.TestCase):
    def run_validate(self, g):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(g, f)
        out = io.StringIO()
        try:
            with redirect_stdout(out), redirect_stderr(io.StringIO()):
                code = validate_graph.main(f.name)
        finally:
            os.unlink(f.name)
        return code, out.getvalue()

    def test_missing_endpoint(self):
        g = copy.deepcopy(build())
        g["edges"].append({"kind": "produce", "from": "app:NOPE", "to": "topic:east:orders.v1", "declared": True})
        code, out = self.run_validate(g)
        self.assertEqual(code, 1)
        self.assertIn("app:NOPE does not exist", out)

    def test_wrong_endpoint_type(self):
        g = copy.deepcopy(build())
        g["edges"].append({"kind": "consume", "from": "app:ORD", "to": "app:PAY", "declared": True})
        code, out = self.run_validate(g)
        self.assertIn("expected a topic", out)

    def test_link_out_needs_mirror_of(self):
        g = copy.deepcopy(build())
        for e in g["edges"]:
            if e["kind"] == "link-out":
                del e["mirrorOf"]
                break
        code, out = self.run_validate(g)
        self.assertIn("mirrorOf is required", out)


if __name__ == "__main__":
    unittest.main()
