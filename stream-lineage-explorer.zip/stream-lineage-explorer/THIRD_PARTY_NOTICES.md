# Third-party notices

This package bundles or loads the following third-party components. Their full license texts are in `vendor/licenses/`.

## Bundled

### Cytoscape.js 3.30.4

- **File:** `vendor/cytoscape.min.js`
- **License:** MIT, see `vendor/licenses/cytoscape-LICENSE.txt`
- **Copyright:** (c) 2016-2024, The Cytoscape Consortium
- **Source:** https://github.com/cytoscape/cytoscape.js

### elkjs 0.9.3 (Eclipse Layout Kernel, compiled to JavaScript)

- **File:** `vendor/elk.bundled.js`
- **License:** Eclipse Public License 2.0, see `vendor/licenses/elkjs-LICENSE.md`
- **Source:** https://github.com/kieler/elkjs. The unmodified source for this version is available there and from the npm package `elkjs@0.9.3`.

## Loaded at runtime, not bundled

### Atkinson Hyperlegible and JetBrains Mono

- **Loaded from:** Google Fonts (`fonts.googleapis.com`, `fonts.gstatic.com`)
- **License:** SIL Open Font License 1.1, for both typefaces

If you self-host these fonts (see docs/DEPLOYMENT.md), include each font's `OFL.txt` alongside the font files.

## This package

The page, tools, schema, examples and documentation in this package were written for this sample and carry no third-party code beyond the components above. Choose a license for them that suits your organization before distributing further.
