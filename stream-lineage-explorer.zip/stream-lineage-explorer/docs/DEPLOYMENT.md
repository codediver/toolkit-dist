# Deployment

The page is static: one HTML file, two JavaScript libraries and a data file. There's no server-side code, so any static host works.

## What to deploy

| Path | Needed at runtime |
|---|---|
| `index.html` | yes |
| `vendor/cytoscape.min.js`, `vendor/elk.bundled.js` | yes |
| `data/graph.json` and/or `data/graph.js` | yes, unless you load data with `?data=` |
| `vendor/licenses/` | recommended, to satisfy the library licenses |
| `docs/`, `tools/`, `schema/`, `Makefile` | no |

## Three ways to open it

### 1. From disk

Double-click `index.html`. Browsers block `fetch()` for pages opened from `file://`, so the page reads `data/graph.js` instead: the same graph wrapped as `window.LINEAGE_DATA = {...};`. Generate it with `build_graph.py --js-out data/graph.js`. This is the easiest way to share a snapshot by email or on a file share: zip `index.html`, `vendor/` and `data/`.

### 2. From a web server

Serve the directory. The page uses `data/graph.js` if present, otherwise it fetches `data/graph.json`. If you serve over HTTP you can publish just `graph.json` and delete `graph.js`.

```bash
python3 -m http.server 8080     # local testing only
```

### 3. With data from somewhere else

Add `?data=` with a URL that returns `graph.json`:

```
https://lineage.internal.example.com/?data=https://artifacts.internal.example.com/lineage/prod/graph.json
```

This takes precedence over `data/graph.js`. The URL must be on the same origin or send CORS headers allowing the page's origin. This lets one copy of the page serve several estates (prod, non-prod, per business unit) from different data files.

## URL parameters

The query string selects data; the hash holds the view, so links are shareable.

| Parameter | Where | Values | Meaning |
|---|---|---|---|
| `data` | query | URL | Graph to load |
| `v` | hash | `app`, `detail` | Level of detail |
| `f` | hash | entity ID, e.g. `app:ORD` | Focus |
| `u`, `d` | hash | 1–12 | Upstream and downstream depth |
| `w` | hash | one of `settings.windows` | Activity window in hours |
| `pf`, `pt` | hash | entity IDs | Show routes from `pf` to `pt` |

Example: `index.html?data=prod.json#v=detail&f=topic:east:orders.v1&u=2&d=4&w=24`

Invalid values are ignored in favor of the defaults in `graph.json` `settings`. Editing the hash in an open tab applies the new view without a reload.

## Hosting examples

### nginx

```nginx
server {
    listen 443 ssl;
    server_name lineage.internal.example.com;
    root /srv/stream-lineage;

    # Data changes every refresh: always revalidate.
    location /data/ {
        add_header Cache-Control "no-cache";
    }
    # The page itself: revalidate so updates roll out immediately.
    location = /index.html {
        add_header Cache-Control "no-cache";
    }
    # Vendored libraries change only when you upgrade them.
    location /vendor/ {
        add_header Cache-Control "public, max-age=604800";
    }

    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'" always;
    add_header X-Content-Type-Options nosniff always;
    add_header Referrer-Policy same-origin always;
}
```

If you load data from another origin with `?data=`, add that origin to `connect-src`. If you self-host the fonts (below), drop the Google Fonts origins.

The page's own script and styles are inline, which is why the policy allows `'unsafe-inline'`. For a stricter policy, move the three inline `<script>` blocks and the `<style>` block into files under `vendor/` or `app/` and remove `'unsafe-inline'`.

### Object storage (S3, GCS, Azure Blob) behind a CDN

Upload the directory as a static site. Set `Cache-Control: no-cache` on `index.html` and `data/*`, and a long max-age on `vendor/*`. Put the CDN behind your SSO (see below).

```bash
aws s3 sync . s3://lineage-site/ --exclude "*" --include "index.html" --include "vendor/*" --include "data/*"
aws s3 cp data/graph.json s3://lineage-site/data/graph.json --cache-control no-cache
```

### Internal Git pages (GitLab Pages, GitHub Enterprise Pages)

Publish from CI (see [Automating refreshes](#automating-refreshes)). Pages usually sit behind your SSO already.

## Security

**Treat the data as internal.** `graph.json` maps your streaming estate: application codes and teams, topic names, service account and identity pool IDs, consumer groups, cluster IDs, IaC file paths, and where access doesn't match policy. That's useful to an attacker planning lateral movement. Serve it only to authenticated employees, for example behind an identity-aware proxy (oauth2-proxy, a cloud load balancer with OIDC, or your SSO gateway).

**Keep secrets out.** The build tools copy only the fields documented in the [data model](DATA_MODEL.md). If you write your own extractor, never pass through API keys, secrets, `config_sensitive` values or connection strings. The `detail` text on principals and the `iacSource` paths are shown to every viewer.

**Data is rendered safely.** Every data-derived string is HTML-escaped before it's inserted into the page, and graph labels are drawn on a canvas. A malicious topic or principal name can't inject markup or script.

**Links shared outside the audience** reveal only the view (focus, depth, window), not the data, as long as the host requires authentication.

## Automating refreshes

Refresh as often as your metrics export allows: hourly is common, nightly is fine for governance use. Publish `graph.json` and `graph.js` together, and only after validation passes.

GitHub Actions example:

```yaml
name: lineage-refresh
on:
  schedule: [{cron: "15 * * * *"}]
  workflow_dispatch: {}
jobs:
  refresh:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {python-version: "3.12"}
      - run: pip install jsonschema
      - name: Export IaC and metrics
        run: |
          ./scripts/extract_iac.sh     > exports/iac.json
          ./scripts/extract_metrics.sh > exports/metrics.json
        env:
          CONFLUENT_CLOUD_API_KEY: ${{ secrets.CC_METRICS_KEY }}
          CONFLUENT_CLOUD_API_SECRET: ${{ secrets.CC_METRICS_SECRET }}
      - name: Build and validate
        run: |
          python3 tools/build_graph.py --iac exports/iac.json --metrics exports/metrics.json \
            --out data/graph.json --js-out data/graph.js --default-focus app:ORD 2> build.log
          python3 tools/validate_graph.py data/graph.json
          cat build.log
      - name: Publish
        run: aws s3 sync . s3://lineage-site/ --exclude "*" --include "index.html" --include "vendor/*" --include "data/*"
```

The same steps work in GitLab CI, Jenkins or a cron job. Give the metrics credentials read-only scope: a service account with the MetricsViewer role in Confluent Cloud.

## Fonts and fully offline use

The page loads Atkinson Hyperlegible and JetBrains Mono from Google Fonts. Without network access it falls back to system fonts and works normally; labels just look slightly different. To be fully self-contained:

1. Download the `woff2` files for Atkinson Hyperlegible (400, 700) and JetBrains Mono (400, 500). Both are under the SIL Open Font License, so include their `OFL.txt`.
2. Put them in `vendor/fonts/` and replace the Google Fonts `<link>` tags in `index.html` with `@font-face` rules pointing at those files.
3. Remove the Google Fonts origins from your Content-Security-Policy.

## Upgrading the vendored libraries

```bash
npm pack cytoscape@<version> elkjs@<version>
tar -xzf cytoscape-<version>.tgz -C vendor/ --strip-components=2 package/dist/cytoscape.min.js
tar -xzf elkjs-<version>.tgz -C vendor/ --strip-components=2 package/lib/elk.bundled.js
```

Copy their license files into `vendor/licenses/`, then check the page: layout, hover tracing, route search, and dark mode. Pinned versions are 3.30.4 (Cytoscape.js) and 0.9.3 (elkjs); the page relies on Cytoscape's `corner-radius` and `underlay-*` styles, which need Cytoscape 3.29 or later.

## Browser support

Current Chrome, Edge, Firefox and Safari, desktop and mobile. The page uses ES2020 JavaScript, CSS custom properties and `env(safe-area-inset-*)`. Internet Explorer isn't supported.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| "No lineage data loaded … Browsers block loading JSON into pages opened from disk" | Opened from `file://` without `data/graph.js` | Run `build_graph.py --js-out data/graph.js`, or serve over HTTP |
| "Couldn't load … (HTTP 404)" | Wrong `?data=` URL or missing `data/graph.json` | Check the path; paths are relative to `index.html` |
| Load error mentioning CORS in the console | `?data=` points at another origin without CORS headers | Serve the data from the same origin, or add `Access-Control-Allow-Origin` |
| "This file is not a schemaVersion 1 lineage graph" | Wrong file, or an incompatible version | Rebuild with this package's `build_graph.py` |
| Old data after a refresh | Cached `graph.json`/`graph.js` | Set `Cache-Control: no-cache` on `data/` |
| Flows missing that you expect | Principal not mapped to an app, or a filter is active | Check the build log for unmapped-principal warnings; check Filters (the button shows a count when any are active) |
| "Showing the nearest 150 of N" | The view hit the size cap | Lower the depth or add filters (see ARCHITECTURE.md) |
| Blank graph, errors in the console | Library failed to load | Check that `vendor/` was deployed and your CSP allows `'self'` scripts |
