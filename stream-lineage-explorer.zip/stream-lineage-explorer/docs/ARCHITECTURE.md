# Architecture

This page is for people changing the code. Everything the browser runs is in `index.html` plus the two libraries in `vendor/`; there's no build step and no framework.

## Components

```
index.html
├── <style>                 design tokens (CSS custom properties), layout, light/dark
├── markup                  top bar, control bar, canvas, details panel, popovers
├── vendor/cytoscape.min.js rendering, pan/zoom, hit-testing, animation
├── vendor/elk.bundled.js   layered (Sugiyama) layout
├── data/graph.js           optional: window.LINEAGE_DATA
├── <script> part 1         data loading: fetchGraph(), loadGraph()
├── <script> part 2         graph logic, pure functions with no DOM access
└── <script> part 3         UI: rendering, panels, search, events, boot
```

## Runtime flow

```
boot
 └─ fetchGraph()  ?data= URL  >  window.LINEAGE_DATA  >  data/graph.json
 └─ loadGraph()   graph.json  ->  NODES (Map), EDGES (Array), CLUSTERS, SETTINGS
 └─ buildIndex()  search index over entities, principals, consumer groups
 └─ applySettings(), readHash()
 └─ render()

render()                                   (runs on every state change)
 ├─ buildDetailed(window, statuses, hiddenClusters)  -> D   physical graph, filtered, with statuses
 ├─ G = view === 'app' ? deriveAppGraph(D) : D
 ├─ computeVisible(G, state)               -> vis  nodes and edges on screen
 ├─ renderChrome(), renderPanel(), renderStatus(), renderTable()
 ├─ writeHash()
 ├─ layoutElk(G, vis)                      -> positions (async)
 └─ draw()                                 -> Cytoscape elements + animated preset layout
```

`state` (part 3) is the single source of truth: view, focus, depths, window, status and cluster filters, expansions, route search, selection, trail, table sort. Every interaction mutates `state` and calls `render()` (or `select()` for selection-only changes, which skips layout).

Renders can overlap because layout is asynchronous. A sequence counter (`renderSeq`) discards stale layouts.

## Graph logic (part 2)

Everything here is pure: it takes graphs and state and returns data, so it's easy to test or reuse server-side.

### Graph structure

`newGraph()` returns `{nodes: Map, edges: Map, out: Map<id, edge[]>, in: Map<id, edge[]>}`. Adjacency lists make each hop O(degree).

### Statuses

`edgeStatus(e, windowHours)` applies the rules in [DATA_MODEL.md](DATA_MODEL.md#how-statuses-are-derived). `buildDetailed` stamps each edge copy with its status and drops edges whose status is filtered out, so filters affect traversal, not just display.

### The pass-through rule

Cluster links and Replicators carry many topics. `outE`/`inE` take a constraint `c`. When a traversal enters a link or Replicator from topic `T`, the constraint is `T`, and only the out-edge whose `pairFrom` (the data's `mirrorOf`) equals `T` is followed. Upstream, it's the reverse: arriving at a link from mirror `M` sets the constraint to `M`'s `pairFrom`, and only the in-edge from that topic is followed. `nextC` computes the constraint for the next step. Every traversal (lineage, route search, app-level derivation, hover trace) goes through these helpers, so the rule is applied consistently.

### Lineage (`lineage`)

Breadth-first search in one direction, up to `maxDepth`, returning the minimum depth per node and the set of edges used. Visited states are keyed by `(node, constraint)`, because a link may legitimately be passed several times for different topics.

### Visible set (`computeVisible`)

1. Upstream and downstream lineage from the focus, at the chosen depths.
2. Expansions: for each node the user expanded, add its immediate neighbours in the requested direction, repeated until stable (expanded nodes can reveal other expanded nodes).
3. **Node cap:** if more than `MAX_VISIBLE_NODES` (150) remain, keep the nearest by hop count. The status bar and a toast say "Showing the nearest 150 of N".
4. **Edge cap:** if lineage edges exceed `MAX_VISIBLE_EDGES` (300), keep those nearest the focus, preferring hop-to-next-hop links over cross links, and report how many were hidden.
5. Induced edges: edges whose ends are both visible are added, within the edge budget, so the picture doesn't hide real connections between things already on screen.

In route mode it instead unions the edges of `findPaths` results.

"n more" counts (`hiddenCounts`) are neighbours not in the visible set. They deliberately ignore the pass-through rule: a link reports the other topics it carries.

### Route search (`findPaths`)

Enumerates simple routes from A to B in data direction, obeying the pass-through rule, **shortest first**:

1. A reverse breadth-first search from B gives every node's minimum distance to B. It ignores the pass-through rule, so it's a lower bound and safe for pruning.
2. Passes run with an increasing length bound, starting at A's distance. Each pass records only routes of exactly that length, and prunes any branch whose length so far plus its remaining distance exceeds the bound.
3. It stops at 60 routes, 36 hops, or a budget of 250,000 edge visits, whichever comes first.

When a cap is hit, the result is marked truncated: the chip shows "60+ found" and the panel says "The 60 shortest routes". A plain depth-first search was used originally, but on dense graphs it filled the cap with long detours before reaching short routes. On the stress graph below it returned only 23-hop routes; this version returns the 5-hop ones first.

### App-level derivation (`deriveAppGraph`)

From each app, a depth-first walk through non-app nodes until it reaches another app; each walk is a route. Routes are grouped per app pair into one edge carrying `paths`, `status`, `rate`, `label`, `crossings` and `hops`. Walks stop at 40 edges.

## Layout

`layoutElk` builds a flat ELK graph of the visible nodes, using sizes measured from their labels, and runs the `layered` algorithm:

- **Direction:** `RIGHT` (upstream left, downstream right), or `DOWN` when the canvas is taller than it is wide (phones)
- **Node placement:** `NETWORK_SIMPLEX` (straightest chains) for views of up to 60 nodes and 120 edges, otherwise `BRANDES_KOEPF` with lower thoroughness. Network simplex is dramatically slower on dense views: 245 seconds for 248 nodes and 923 edges on the stress graph, against about 3 seconds for Brandes-Köpf.
- **Fallback:** if ELK throws (a dense enough view can overflow its recursion), `fallbackLayout` places nodes in one column per signed hop distance from the focus, so the page still draws something.
- **Model order:** children are inserted sorted by signed hop distance (upstream negative), and `considerModelOrder` is set, so layouts stay stable as you step depth up and down
- **Cycles:** ELK breaks them internally, so bidirectional replication and feedback loops need no special handling

**Why no cluster containers?** An earlier version grouped nodes into boxes per cluster. It made the layout worse, because apps sit between clusters: one app reads from one cluster and writes to another, so data had to bend back into the same box. Cluster membership is now shown by topic fill color and a second label line, and crossings are visible as link and Replicator nodes.

Cytoscape then applies the positions with a `preset` layout, animating from previous positions (new nodes grow out of the focus). Animation is skipped when `prefers-reduced-motion` is set. The zoom a fit can reach is capped at 1.35 so small graphs don't render oversized.

Edges are drawn as Bezier curves rather than ELK's routed polylines. That's simpler and robust to animation, at the cost of the occasional edge crossing a node on very dense layouts.

## Rendering and styling

Colors live in CSS custom properties on `:root`, redefined for dark mode. `tokens()` reads their computed values for Cytoscape, which draws on a canvas and can't use `var()`, and `cyStyle()` builds the stylesheet. Theme changes re-apply the style automatically.

| Token | Used for |
|---|---|
| `--app`, `--app-text` | Application nodes |
| `--connector*`, `--link*`, `--rep*` | Connector, cluster link and Replicator nodes |
| `--ok`, `--lag`, `--idle`, `--drift` | Flow statuses |
| `--tint-0` … `--tint-7` | Cluster fills for topics, assigned in cluster order |
| `--accent` | Focus, selection, interactive highlights |

Fonts are Atkinson Hyperlegible (labels and UI, chosen for legibility at small canvas sizes) and JetBrains Mono (literal identifiers only: topic names, principal IDs, groups, file paths), both loaded from Google Fonts with system fallbacks. See [DEPLOYMENT.md](DEPLOYMENT.md#fonts-and-fully-offline-use) to self-host them.

## Performance

Only the visible subgraph is laid out and drawn, so the size of the estate matters much less than how much is on screen. The guardrails above bound that.

Measured in headless Chromium on a synthetic **stress graph**: 600 apps, 1,500 topics and 5,283 randomly wired edges. Random wiring is much denser and less tree-like than a real estate, so treat these as worst cases.

| Operation | Time |
|---|---|
| Derive all app-to-app flows (3,757 flows) | 21 ms |
| Apps only, depth 2 (61 nodes) | 0.4 s |
| Apps only, depth 3 or 6 (capped at 150 nodes, 300 edges) | 1.0–1.1 s |
| Every hop, depth 3 or 6 | 0.2–0.3 s |
| Route search, 60 shortest routes | 0.4–0.6 s |

Before the guardrails, depth 3 in Apps only view on the same graph took minutes to lay out, and in one run crashed ELK.

ELK runs on the main thread (`elk.bundled.js`), so the page doesn't respond to input while a layout runs. If your estate regularly produces slow views, you can:

- lower `MAX_VISIBLE_NODES` and `MAX_VISIBLE_EDGES` at the top of the graph logic
- lower the default depth in `settings`
- run ELK in a Web Worker: elkjs ships `lib/elk-worker.min.js`; construct `new ELK({workerUrl: 'vendor/elk-worker.min.js'})` when served over HTTP (workers don't start from `file://`), then terminate the worker and use `fallbackLayout` if it exceeds a time limit
- precompute app-level edges in `build_graph.py`, if app-level derivation ever shows up in profiles

The app-panel reach calculation re-derives the unfiltered app graph each time an app is selected. That's cheap at the sizes above, but worth caching if it isn't for you.

## Extension points

**Change thresholds or defaults:** use `settings` in `graph.json` or the build flags. No code change is needed.

**Add an entity type** (for example ksqlDB queries or Flink statements as first-class nodes):

1. `loadGraph`: add the node with a new `type` and ID prefix.
2. `schema/graph.schema.json` and `tools/validate_graph.py`: add the array, the ID prefix and new edge kinds in `KIND_TYPES`.
3. `labelLines`, `sizeFor`, `typeLabel`, `TYPE_LABEL`, `cyStyle` (shape and colors), the legend markup, and the chip CSS class.
4. `panelNode`: a branch for its details. `evidence` and `KIND_LABEL`: its edge kinds.
5. If it carries several independent streams the way a link does, include it in `isPass` and give its out-edges `pairFrom`.

**Add an evidence field:** carry it through `loadGraph` into the edge object and render it in `evidence()`. Unknown `graph.json` fields are otherwise ignored, so producers can add data before the page shows it.

**Real sparkline history:** populate `observed.series` (see the data model). `spark()` uses it automatically.

**Live data:** `fetchGraph` is the single entry point. Point `?data=` at an API that returns `graph.json`, or replace the function. The page doesn't poll; reload to refresh, or add a timer that calls `fetchGraph()`, `loadGraph()`, `buildIndex()` and `render()`.

## Testing

- `make test` runs `tools/test_tools.py`: build rules (declared/observed join, drift, idle grants, unmanaged principals and topics, prefix bindings, connector principals, mirror pairing) and validator rules.
- The page has no automated tests in this package. Browser tests with Playwright work well: load `index.html?data=…`, then assert on `NODES`, `state` and `cy.nodes()`, which are globals.

## Known limitations

- Hover tracing needs a pointer; touch users rely on selection.
- Route search returns at most the 60 shortest routes, marked "60+" when there are more.
- The visible-set caps can hide farther parts of a very large view; the page always says when it has.
- Bezier edges can pass behind nodes on dense layouts.
- Status is a snapshot as of `generatedAt`; the page doesn't poll.
- Search is substring matching, not fuzzy matching.
