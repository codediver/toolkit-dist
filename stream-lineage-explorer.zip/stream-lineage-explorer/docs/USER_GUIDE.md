# User guide

This guide covers everything on the page. For where the data comes from, see the [integration guide](INTEGRATION.md).

## The core idea

The page never draws your whole estate at once. You pick something to **focus** on (an application, topic, connector, cluster link or Replicator), and the page shows what feeds it (upstream, on the left) and what it feeds (downstream, on the right), a few hops in each direction. You widen the view as you need to, rather than starting from a tangle.

Every line between two things is a **flow**, and every flow has a status that compares your IaC with your metrics.

## Screen layout

- **Top bar:** search, the level of detail (Apps only / Every hop), and the activity window.
- **Control bar:** the focus trail, upstream and downstream depth, Find paths, Filters, Graph/Table, Copy link.
- **Canvas:** the lineage graph, with zoom controls (top right), the legend (bottom left) and a status summary (bottom right).
- **Details panel** (right, or below the graph on phones): whatever you've selected, or an overview when nothing is selected.

## Levels of detail

**Apps only** shows applications and the data flowing between them. Each line is one app-to-app relationship, labeled with the topic it travels through (with "+n" if more than one topic is involved). A single line can stand for a long physical route. For example, SHP → DWH goes through `shipments.v1`, a cluster link, a mirror topic and a sink connector. Hover a line to see how many routes it stands for and which links or Replicators it crosses, or click it to list every route.

**Every hop** shows every physical step: topics, connectors, cluster links and Replicators. Topic fill color shows which cluster the topic lives on (see the legend). Use this view to see exactly where data crosses between clusters.

Switching views keeps your focus where possible. If you're focused on a topic and switch to Apps only, the focus moves to the nearest application.

## Flow statuses

| Status | Line style | Meaning |
|---|---|---|
| Active | Solid green, thicker when busier | Declared in IaC, and traffic was seen within the activity window |
| Lagging | Solid amber | Declared and active, but consumer lag is above the configured threshold (10,000 messages by default) |
| No traffic | Dashed grey | Declared in IaC, but no traffic was seen within the activity window. This is often a stale grant worth removing. |
| Not in IaC | Dotted red | Traffic was seen in metrics, but no role binding or resource in IaC grants it. Access was probably granted by hand. |

In Apps only view, a line takes the status of its routes. It's **Not in IaC** if any route relies on undeclared access. Otherwise it's **Lagging** if any route is lagging, **Active** if any route is active, and **No traffic** only when every route is idle.

**Unmanaged principals** are principals seen in metrics that aren't mapped to any application code. They appear as application nodes named after the principal ID, with a dashed red outline. **Unmanaged topics**, seen in metrics but not defined in IaC, are flagged in their details panel.

## Activity window

"Activity in last" (24 hours, 7 days or 30 days by default) sets what counts as active. A flow last seen 30 hours ago is **Active** in the 7-day window but **No traffic** in the 24-hour window. Changing the window recolors the graph and updates the Needs attention list; it doesn't change which entities exist.

## Navigating

### Search

Press `/` or click the search box. Search matches:

- application codes, names and teams (`ORD`, `Order Service`, `Supply Chain`)
- topic names (the same topic on several clusters shows as several results)
- connector, cluster link and Replicator names
- service account IDs, identity pool IDs and CP principals (`sa-9zz81k`, `pool-4kLq`, `User:svc-pos`), which resolve to the owning application
- consumer group IDs (`frd-scoring`), which resolve to the consuming application

Use the arrow keys and Enter to pick a result, or click one. Picking a result focuses the graph on it. If you pick a topic, connector, link or Replicator while in Apps only view, the page switches to Every hop.

### Focus, depth and the trail

The focused entity has a blue halo. Upstream and Downstream set how many hops to show on each side (1 to 12). In Apps only view a hop is one app-to-app step; in Every hop view each node is a hop.

The **trail** in the control bar records where you've been. Click an earlier entry to go back to it.

### Hover to trace

Hover any node to fade everything that isn't part of its lineage, both upstream and downstream, within what's on screen. Hover a line to isolate it and its two ends. This is the fastest way to answer "what depends on this?"

### Reveal more

Nodes with a **dashed outline** have more lineage beyond the current view. The label shows how much, for example "◂ 1 more   4 more ▸". Double-click the node to reveal one more hop in both directions. You can also select it and use **Show n upstream** or **Show n downstream** in the details panel. Changing depth or focus resets these expansions.

A cluster link or Replicator often shows "n more": it carries other topics that aren't on the route you're following.

### Find paths

**Find paths** answers "how does data get from A to B?". Choose a start and an end; the lists accept application codes and names, and in Every hop view any entity. The graph then shows only the routes between them, and the details panel lists each route shortest first, with each step colored by status.

- Hover a route in the panel to isolate it on the graph.
- Click an arrow in a route to open that step's evidence.
- **Routes from here** and **Routes to here** in a node's panel pre-fill the finder.
- From an app-to-app line's panel, **Show every hop** opens the same routes in Every hop view.
- If there's no route in the direction you asked but there is one the other way, the page offers to swap.

Press Escape or click ✕ on the route chip to return to normal focus.

### Filters

- **Flow status:** hide flows by status. For example, untick No traffic to see only live data paths, or untick everything except Not in IaC to see drift. Hidden flows are removed before tracing, so routes that depend on them disappear too.
- **Clusters:** hide every entity on a cluster. Links and Replicators touching a hidden cluster are hidden as well, which is useful for questions like "what still flows if analytics is down?"

### Table view

**Table** lists what's currently in view: entity, type, cluster, direction relative to the focus, hops, worst status of its flows, throughput and last activity. Click a column header to sort. Click a row to show its details; double-click to focus on it.

## Details panel

**Nothing selected** shows the focus summary, when the data snapshot was taken, and **Needs attention**. That list covers the whole estate, not just what's on screen: undeclared access, lagging consumers and unused grants for the current window. Click an item to jump to its evidence.

**An application** shows its reach (how many apps its data reaches, and how far), its identities (service accounts, identity pools, CP principals), the topics it writes and reads with consumer groups and lag, the connectors it owns, and a traffic sparkline.

**A topic** shows its configuration, where it's defined in IaC, what it's a mirror or replica of, and who writes and reads it.

**A connector** shows its owner, class, tasks, IaC source, and the topics it reads or writes.

**A cluster link or Replicator** shows the source and destination clusters, owner, IaC source, and every topic it carries with its lag.

**A flow** (a line in Every hop view) shows its status with an explanation, then two sections side by side:

- **Declared in IaC:** the role bindings (role, resource, principal, file) or connector/link definition that make it legitimate, or a note that nothing in IaC grants it
- **Observed in metrics:** principal seen, consumer group, rate, throughput, lag, last activity

**An app-to-app line** lists every physical route it stands for.

Sparklines use real history when the data provides it. Otherwise they show an illustrative shape based on the current rate and last-seen time, and say so underneath.

## Sharing a view

The page keeps its state in the address bar: view, focus, depth, activity window, and any active route search. **Copy link** copies it; anyone opening the link sees the same view. The parameters are listed in [DEPLOYMENT.md](DEPLOYMENT.md#url-parameters).

## Keyboard shortcuts

| Key | Action |
|---|---|
| `/` | Focus search |
| ↑ ↓ Enter | Move through and pick search results |
| Escape | Close search; leave route view; clear selection |
| `F` | Fit the graph to the screen |

## Phones and tablets

On narrow screens the graph lays out top to bottom instead of left to right, and the details panel moves below it. Tap to select; use the zoom buttons or pinch to zoom. Hover tracing needs a pointer, so on touch devices use selection and the details panel instead.

## Light and dark

The page follows your system's light or dark setting.
