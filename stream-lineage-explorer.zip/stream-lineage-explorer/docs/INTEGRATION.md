# Integration guide

This guide explains how to produce `graph.json` from your real IaC and metrics. The reference implementation is `tools/build_graph.py`. It takes two exports, one per side of the truth, and joins them:

```
 IaC export (declared)  ──┐
                          ├──> build_graph.py ──> graph.json ──> validate_graph.py ──> publish
 metrics export (seen)  ──┘
```

You write two small extractors for your environment, one per export, and reuse `build_graph.py` as is. Or you can treat it as a specification and produce `graph.json` directly from your own pipeline; the [data model](DATA_MODEL.md) is the contract.

Worked examples of both exports are in `tools/examples/`; running `make build` on them produces the sample graph.

## Contents

1. [The IaC export](#1-the-iac-export)
2. [The metrics export](#2-the-metrics-export)
3. [How the join works](#3-how-the-join-works)
4. [Sourcing the IaC export](#4-sourcing-the-iac-export)
5. [Sourcing the metrics export](#5-sourcing-the-metrics-export)
6. [Tracking "last seen" beyond metrics retention](#6-tracking-last-seen-beyond-metrics-retention)
7. [Build options](#7-build-options)
8. [Running it on a schedule](#8-running-it-on-a-schedule)
9. [Known gaps and how to handle them](#9-known-gaps-and-how-to-handle-them)

## 1. The IaC export

One JSON document describing everything your IaC declares, across every application code. See `tools/examples/iac_export.json`.

| Key | Each item | Notes |
|---|---|---|
| `exportedAt`, `exportedFrom` | strings | Provenance, copied into `graph.json` |
| `clusters` | `id, platform (CC/CP), name, externalId, region` | `id` is your own short key, used everywhere else |
| `apps` | `code, name, team, iacPath` | One per application code |
| `principals` | `id, kind, app, detail` | Maps every service account, identity pool and CP principal to its app. `kind`: `service-account`, `identity-pool`, `cp-principal` or `user`. **This mapping is what makes the join work.** |
| `topics` | `cluster, name, partitions, retention, schema, iacSource` | Mirror topics may be omitted; links create them |
| `roleBindings` | `principal, role, cluster, resourceType (Topic/Group), resourceName, patternType (LITERAL/PREFIXED), iacSource` | Topic and consumer-group bindings only; others are ignored |
| `connectors` | `name, cluster, app, class, direction (sink/source), tasks, principal, topics[], iacSource` | `topics` are names on the connector's cluster. `principal` is the connector's own identity (see section 3). |
| `clusterLinks` | `name, sourceCluster, destinationCluster, mirrorTopics[], owner, iacSource` | |
| `replicators` | `name, sourceCluster, destinationCluster, topics[{source, destination}], host, renameRule, owner, iacSource` | Pairs are explicit because Replicator can rename topics |

## 2. The metrics export

One JSON document of aggregated observations over a lookback period. See `tools/examples/metrics_export.json`. Rates are messages per second averaged over the periods when the flow was active; `lastSeenHoursAgo` is relative to `collectedAt`.

| Key | Each item | Notes |
|---|---|---|
| `collectedAt`, `collectedFrom`, `lookbackHours` | | Provenance; `collectedAt` becomes `generatedAt` |
| `topicStats` | `cluster, topic, avgRecordBytes` | Optional; enables KB/s figures |
| `produce` | `cluster, topic, principal, rateMsgs, lastSeenHoursAgo` | One per (topic, producing principal) |
| `consume` | `cluster, topic, group, principal, rateMsgs, lag, lastSeenHoursAgo` | One per (topic, consumer group). `principal` may be `null` if unknown. |
| `mirrors` | `link, topic, state, rateMsgs, lag, lastSeenHoursAgo` | One per (cluster link, mirrored topic) |
| `replicators` | `name, sourceTopic, rateMsgs, lag, lastSeenHoursAgo` | One per (Replicator, source topic) |
| `connectors` | `name, status, tasksRunning, rateMsgs, lastSeenHoursAgo, topics[{topic, rateMsgs, lag}]` | One per connector |

## 3. How the join works

`build_graph.py` applies these rules in order.

**Declared client flows.** For each Topic role binding whose principal maps to an app:

- `DeveloperWrite` or `ResourceOwner` creates a declared `produce` edge (app → topic).
- `DeveloperRead` or `ResourceOwner` creates a declared `consume` edge (topic → app).
- `PREFIXED` bindings match every topic on that cluster whose name starts with the prefix.

Connector principals are skipped, because connectors get their own edges.

**Observed produce.** Each `produce` record is attributed to the app owning its principal. If the edge already exists, the observation is merged into it. If it doesn't, an undeclared edge is created: that's drift. Records from connector principals are ignored.

**Observed consume.** Each `consume` record is attributed to an app in this order:

1. the app owning `principal`, if given and known
2. the app whose `Group` role binding covers `group` (LITERAL or PREFIXED match) on that cluster
3. otherwise an **unmanaged** app, named after the principal (or `group:<id>`), flagged `unmanaged: true`

The record's group is attached to the edge. For declared edges, the matching Group binding is added to the edge's evidence; if there isn't one, the build prints a warning.

**Unknown topics.** A metrics record for a topic not in IaC creates the topic with `unmanaged: true`.

**Idle grants.** Declared consume edges with no observation keep no `observed` block; they show as **No traffic**. If the app has exactly one LITERAL Group binding on that cluster, it's used as the edge's group.

**Cluster links.** Each `mirrorTopics` entry produces `link-in` and `link-out` edges with `mirrorOf` set, and the destination topic is created if IaC didn't list it. Partitions and schema are copied from the source. Observations come from `mirrors`.

**Replicators.** The same, using the explicit `topics` pairs, so renamed topics link correctly.

**Connectors.** A sink produces `sink-in` edges (one per topic, group `<prefix><name>`) and a `sink-out` edge to its owner. A source produces `source-in` from its owner and `source-out` edges to its topics. Observations come from `connectors`.

When several records hit one edge, their rates are summed, the maximum lag is kept, and the most recent `lastSeenHoursAgo` wins.

The build prints a summary to stderr, listing drift edges, declared edges never observed, unmanaged principals and warnings. It's worth keeping in your job logs.

## 4. Sourcing the IaC export

How you produce this depends on how your IaC is organized. These are starting points.

### Terraform with the Confluent provider

Run `terraform show -json` per workspace (or read state from your backend) and walk `values.root_module` and its `child_modules`. The resource types that matter:

| IaC export key | Confluent provider resources |
|---|---|
| `clusters` | `confluent_kafka_cluster` |
| `principals` | `confluent_service_account`, `confluent_identity_pool` (with its `confluent_identity_provider`) |
| `topics` | `confluent_kafka_topic` |
| `roleBindings` | `confluent_role_binding`. Parse `crn_pattern`: the segment after `/topic=` or `/group=` is the resource name, and a trailing `*` means PREFIXED. |
| `connectors` | `confluent_connector` (`config_nonsensitive` holds `connector.class`, `topics` and `kafka.service.account.id`) |
| `clusterLinks` | `confluent_cluster_link`, plus `confluent_kafka_mirror_topic` for `mirrorTopics` |

If you use `confluent_kafka_acl` instead of or alongside RBAC, map ACLs to role bindings: `WRITE` on a topic to `DeveloperWrite`, `READ` on a topic or group to `DeveloperRead`, and a `PREFIXED` pattern type to PREFIXED.

The app code usually comes from your module structure (one module or workspace per app code) or from a tag or label convention. Put the path in `iacSource` so the page can point people at the right file.

A sketch with `jq`, for one workspace:

```bash
terraform show -json | jq '
  [.values.root_module | .. | objects | select(.type? == "confluent_kafka_topic")]
  | map({cluster: .values.kafka_cluster[0].id, name: .values.topic_name,
         partitions: .values.partitions_count, iacSource: .address})'
```

Then translate cluster IDs such as `lkc-…` into your short cluster `id`s.

### Confluent Platform

CP RBAC is often managed through cp-ansible, the Confluent CLI against MDS, or a GitOps repo of role bindings. Export from whichever holds the source of truth, and use `cp-principal` principals such as `User:svc-pos`. If your CP clusters use ACLs, map them as above. Replicator configurations usually live alongside Connect deployment config; take `topic.whitelist`/`topic.regex` and `topic.rename.format` from there to build the explicit `topics` pairs.

### Validating the mapping

Before trusting the graph, check that every principal in your role bindings appears in `principals`. The build warns about bindings whose principal isn't mapped to an app. An unmapped principal is the most common reason flows go missing.

## 5. Sourcing the metrics export

The page needs, per flow, a rate, a lag where relevant, and **how long ago it was last active**. Collect over your largest window (30 days by default) or keep your own history (section 6).

Metric and label names below are the ones documented at the time of writing. Availability varies by cluster type and changes over time, so **check each against the Confluent Cloud Metrics API reference for your cluster types before relying on it.**

### Confluent Cloud

**Consume and lag.** `io.confluent.kafka.server/consumer_lag_offsets`, grouped by `metric.consumer_group_id` and `metric.topic`, gives lag per group and topic; a group appearing at all means it's active or recently active. The Metrics API emits lag for groups in the STABLE state, and for groups that have been EMPTY for less than a day. Groups whose consumers use `assign()` instead of subscribing don't appear. For those, fall back to the Admin API (committed offsets per group) or client metrics.

Lag metrics identify the **group**, not the principal, so consumers are usually attributed through Group role bindings. That's why consistent group-naming prefixes per app code (`pay-*`, `frd-*`) make this work well. Consume rate per group can be estimated from the change in committed offsets between samples.

**Produce.** `io.confluent.kafka.server/received_records` and `received_bytes`, grouped by `metric.topic`, give ingress per topic. The Metrics API also offers principal-level breakdowns (`metric.principal_id`) on some metrics. Where you can split produce traffic by both topic and principal, do so. Where you can't:

- Attribute a topic's ingress to its single declared writer when it has only one.
- For topics with several declared writers, record each writer as observed only if you have per-principal evidence (client metrics, or principal-level request metrics), and flag the rest for review.
- Use the principal-level request metrics to detect principals producing to the cluster that aren't in IaC at all.

**Cluster links.** `io.confluent.kafka.server/cluster_link_mirror_topic_bytes` and `cluster_link_mirror_topic_offset_lag`, filtered by `metric.link_name` and grouped by `metric.topic`, give mirror throughput and lag per link and topic. Mirror state (ACTIVE, PAUSED, FAILED) comes from the cluster link REST API or CLI. Note that `received_bytes` on the destination doesn't include mirror-in bytes, so don't double-count mirrored topics as produced.

**Managed connectors.** Connector metrics in the `io.confluent.kafka.connect/` namespace (for example `received_records` and `sent_records`, filtered by `resource.connector.id`) give throughput. Connector and task status comes from the Connect REST API. Sink lag is the lag of the connector's consumer group; managed connectors use groups named `connect-lcc-<id>`, so set `--connect-group-prefix` or translate the IDs in your extractor.

The Metrics API also has an `/export` endpoint in Prometheus format. If you already scrape it into Prometheus, Datadog or similar, query that store instead: it also solves the history problem in section 6.

### Confluent Platform

- **Produce and consume per principal:** broker JMX exposes per-user and per-client-id request metrics for quota tracking (the `kafka.server` Produce and Fetch quota MBeans). Depending on your version and configuration, these may only be populated when quotas are configured, so check yours. If you have Confluent audit logs with produce and fetch events enabled, they're definitive, but high volume.
- **Topic throughput:** `kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec,topic=…`
- **Consumer lag:** committed offsets from the Admin API (`listConsumerGroupOffsets`) against log-end offsets, or from Control Center, or your existing lag exporter
- **Replicator:** Replicator's Connect task metrics and its consumer group lag on the source cluster
- **Self-managed connectors:** Connect REST API for status; Connect worker JMX for throughput

### Mapping principals in metrics

Metrics report principals by ID (`sa-…`, `pool-…`, `User:…`). Make sure your `principals` list uses the same form. For identity pools, the metric principal is the pool ID, not the external identity, so map pools to apps rather than individual OAuth clients.

## 6. Tracking "last seen" beyond metrics retention

The status logic needs to know that a grant hasn't been used for, say, 30 days. Metrics backends don't always keep that much history at the resolution you need.

The robust approach is a small state table, updated every run:

```
edge_key (kind, cluster, topic, principal|group)  ->  last_active_at, last_rate, last_lag
```

- When a run observes activity, set `last_active_at = now` and update the rate and lag.
- When it doesn't, leave the row alone.
- When writing the metrics export, emit every row with `lastSeenHoursAgo = now - last_active_at`.
- Expire rows older than your longest window plus a margin.

A SQLite file, a DynamoDB table or a Postgres table all work. The example exports' `lookbackHours: 2160` (90 days) assumes such a store.

## 7. Build options

```
python3 tools/build_graph.py --iac IAC.json --metrics METRICS.json [options]

  --out PATH                 graph.json path (default data/graph.json)
  --js-out PATH              also write graph.js so index.html works from file://
  --title TEXT               page title
  --lag-threshold N          lag (messages) above which a flow is Lagging (default 10000)
  --windows 24,168,720       activity windows in hours
  --default-window H         must be one of --windows (default 168)
  --default-view app|detail  initial level of detail
  --default-focus ID         entity to open on, e.g. app:ORD
  --default-depth N          initial upstream and downstream depth (default 3)
  --connect-group-prefix P   sink connector consumer group prefix (default "connect-")
```

The build uses only the standard library. It's a single class, `GraphBuilder`, with one method per join step, so you can subclass it to change a rule, such as how unmanaged principals are named or which roles count as write access.

## 8. Running it on a schedule

A typical job runs hourly or nightly:

```bash
set -euo pipefail
./extract_iac.sh      > exports/iac.json        # your extractor
./extract_metrics.sh  > exports/metrics.json    # your extractor, reads/updates the last-seen store
python3 tools/build_graph.py --iac exports/iac.json --metrics exports/metrics.json \
        --out site/data/graph.json --js-out site/data/graph.js --default-focus app:ORD 2> build.log
python3 tools/validate_graph.py site/data/graph.json
# publish site/ (see DEPLOYMENT.md)
```

Fail the job if validation fails, so a bad export never replaces a good graph. The drift section of `build.log` is also a useful feed for a Slack channel or a ticket queue.

## 9. Known gaps and how to handle them

| Situation | Effect | Mitigation |
|---|---|---|
| Several apps share one service account | Their traffic can't be told apart; all of it lands on whichever app owns the principal | One principal per app code, enforced in IaC review |
| Produce metrics can't be split by principal | Multi-writer topics can't prove which writers are active | See section 5; flag multi-writer topics |
| Consumers using `assign()` | No group lag in the Metrics API | Admin API offsets or client metrics |
| Wildcard (`*`) bindings | Every matching topic gets a declared edge, which can inflate No traffic counts | Prefer narrow prefixes; review idle grants periodically |
| Consumer group matches several apps' prefixes | Attributed to the first match alphabetically, with a warning | Make prefixes unique per app code |
| Topics renamed by a mechanism other than Replicator | Lineage breaks at the rename | Add explicit edges in your extractor |
| Non-Kafka hops (Flink, ksqlDB, stream processors) | An app that consumes and produces already bridges its topics; managed processing jobs don't appear | Model each job as an app with its own principal, or extend the model (see ARCHITECTURE.md) |
