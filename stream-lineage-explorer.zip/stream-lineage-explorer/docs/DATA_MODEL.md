# Data model: graph.json

`index.html` renders a single JSON document, `graph.json`. This page is the reference for it. The machine-readable version is [`schema/graph.schema.json`](../schema/graph.schema.json), and `tools/validate_graph.py` enforces both.

You don't have to write this file by hand. `tools/build_graph.py` produces it from an IaC export and a metrics export (see the [integration guide](INTEGRATION.md)). Read this page if you're writing your own producer, or need to know exactly what the page does with each field.

## Design principles

- **Entities are the things data passes through**: applications, topics, connectors, cluster links, Replicators. Clusters group topics and connectors.
- **Identity is evidence, not a node.** Principals, identity pools and role bindings are attached to applications and edges. Making them nodes would double the depth of every route and bury the data flow.
- **Every edge carries both truths.** `declared` says whether IaC grants or creates the flow; `observed` says whether and when traffic was seen. The page derives statuses from these two.
- **Edges are physical hops.** App-to-app relationships aren't stored; the page derives them from the physical edges (see [Derived app-level flows](#derived-app-level-flows)).

## Top level

```json
{
  "schemaVersion": 1,
  "generatedAt": "2026-09-27T06:00:00Z",
  "sources": { "iac": "...", "iacExportedAt": "...", "metrics": "...", "metricsLookbackHours": 2160 },
  "settings": { ... },
  "clusters": [ ... ],
  "apps": [ ... ],
  "topics": [ ... ],
  "connectors": [ ... ],
  "clusterLinks": [ ... ],
  "replicators": [ ... ],
  "edges": [ ... ]
}
```

| Field | Required | Notes |
|---|---|---|
| `schemaVersion` | yes | Must be `1`. The page refuses other versions. |
| `generatedAt` | yes | ISO-8601. Shown as "Snapshot from …" in the overview panel. |
| `sources` | no | Free-form provenance. Shown as a tooltip on the snapshot line. |
| `settings` | no | Defaults for the page (below). |
| `clusters`, `apps`, `topics`, `edges` | yes | May be empty arrays. |
| `connectors`, `clusterLinks`, `replicators` | no | Omit if you have none. |

### settings

| Field | Default | Meaning |
|---|---|---|
| `title` | `"Stream lineage"` | Page title and header text |
| `lagThreshold` | `10000` | Consumer lag (messages) above which an active flow is **Lagging** |
| `windows` | `[24, 168, 720]` | Activity windows offered, in hours. Multiples of 24 above 24 are labeled in days. |
| `defaultWindow` | `168` | Must be one of `windows` |
| `defaultView` | `"app"` | `"app"` (Apps only) or `"detail"` (Every hop) |
| `defaultFocus` | first managed app | Entity ID to open on |
| `defaultUpstream`, `defaultDownstream` | `3` | Initial depth, 1–12 |

The URL hash overrides these for a given link (see [DEPLOYMENT.md](DEPLOYMENT.md#url-parameters)).

## Entity IDs

Edges refer to entities by ID. IDs are derived from each entity's fields, so they never appear on the entities themselves.

| Entity | ID format | Example |
|---|---|---|
| Application | `app:<code>` | `app:ORD` |
| Topic | `topic:<clusterId>:<name>` | `topic:east:orders.v1` |
| Connector | `conn:<name>` | `conn:snowflake-sink` |
| Cluster link | `link:<name>` | `link:cl-east-analytics` |
| Replicator | `rep:<name>` | `rep:rep-pos-dc1-east` |

Topic IDs include the cluster because the same topic name on two clusters (a source and its mirror) are different entities. Connector, link and Replicator names must be unique across the file; prefix them with the cluster if yours aren't.

## Entities

### clusters

```json
{ "id": "east", "platform": "CC", "name": "prod-east", "externalId": "lkc-8x2k1", "region": "AWS us-east-1" }
```

| Field | Required | Notes |
|---|---|---|
| `id` | yes | Short, stable, `[A-Za-z0-9_.-]+`. Used inside topic IDs. |
| `platform` | yes | `CC` (Confluent Cloud) or `CP` (Confluent Platform) |
| `name` | yes | Display name |
| `externalId`, `region` | no | Shown in topic details |

Clusters get a fill color in listed order; eight colors cycle.

### apps

```json
{
  "code": "PAY", "name": "Payments", "team": "Payments Engineering", "iacPath": "apps/pay/",
  "principals": [ { "id": "pool-4kLq", "kind": "Identity pool", "detail": "Okta, claims.aud == \"pay-svc\"" } ]
}
```

| Field | Required | Notes |
|---|---|---|
| `code` | yes | Application code. Keep it short; it's the node label. |
| `name` | yes | Shown under the code |
| `team`, `iacPath` | no | Shown in details |
| `principals` | no | Service accounts, identity pools and CP principals. `id` is searchable and resolves to this app. `kind` and `detail` are display text. |
| `unmanaged` | no | `true` for a principal seen in metrics but not mapped to any app. Drawn with a dashed red outline. |

### topics

```json
{ "cluster": "east", "name": "orders.v1", "partitions": 24, "retention": "14 days",
  "schema": "orders.v1-value (Avro)", "avgBytes": 1400, "iacSource": "apps/ord/cc/prod-east/topics.tf" }
```

| Field | Required | Notes |
|---|---|---|
| `cluster`, `name` | yes | `cluster` must be a cluster `id` |
| `partitions`, `retention`, `schema`, `iacSource` | no | Display only. `retention` is free text. |
| `avgBytes` | no | Average record size in bytes, used to convert msg/s into KB/s |
| `unmanaged` | no | `true` for a topic seen in metrics but not defined in IaC |

Mirror and replica topics are ordinary topics on their destination cluster. What makes them mirrors is the `link-out` or `rep-out` edge that writes them.

### connectors

```json
{ "name": "snowflake-sink", "cluster": "analytics", "owner": "DWH", "class": "SnowflakeSink",
  "direction": "sink", "tasks": 4, "iacSource": "apps/dwh/connectors/snowflake-sink.tf" }
```

`owner` is an app **code** (not an ID). `direction` is `sink` or `source`. A sink connector delivers data to its owning app's system; a source connector brings data from it.

### clusterLinks

```json
{ "name": "cl-east-analytics", "sourceCluster": "east", "destinationCluster": "analytics",
  "owner": "Platform team", "iacSource": "platform/cluster-links/cl-east-analytics.tf" }
```

### replicators

```json
{ "name": "rep-pos-dc1-east", "sourceCluster": "dc1", "destinationCluster": "east",
  "host": "Connect worker cluster connect-dc1", "renameRule": "topic.rename.format strips the \".raw\" suffix",
  "owner": "Platform team", "iacSource": "platform/replicators/rep-pos-dc1-east.yaml" }
```

## Edges

```json
{
  "kind": "consume",
  "from": "topic:east:orders.v1",
  "to": "app:PAY",
  "declared": true,
  "group": "pay-order-processor",
  "bindings": [
    { "principal": "pool-4kLq", "role": "DeveloperRead", "resource": "Topic:orders.v1", "source": "apps/pay/cc/prod-east/rbac.tf" },
    { "principal": "pool-4kLq", "role": "DeveloperRead", "resource": "Group:pay-*", "source": "apps/pay/cc/prod-east/rbac.tf" }
  ],
  "observed": { "lastSeenHoursAgo": 0, "rateMsgs": 380, "lag": 40, "principal": "pool-4kLq" }
}
```

Edges always point in the **direction data flows**.

### Edge kinds

| `kind` | from → to | Meaning |
|---|---|---|
| `produce` | app → topic | The app writes to the topic |
| `consume` | topic → app | The app reads the topic |
| `link-in` | topic → link | A source topic mirrored by the link |
| `link-out` | link → topic | The mirror topic the link writes. **Requires `mirrorOf`.** |
| `rep-in` | topic → replicator | A source topic read by Replicator |
| `rep-out` | replicator → topic | The destination topic Replicator writes. **Requires `mirrorOf`.** |
| `sink-in` | topic → connector | A topic a sink connector reads |
| `sink-out` | connector → app | The sink connector delivers into its owner's system |
| `source-in` | app → connector | A source connector reads from its owner's system |
| `source-out` | connector → topic | A topic a source connector writes |

The validator rejects edges whose endpoints are the wrong entity type.

### Edge fields

| Field | Required | Notes |
|---|---|---|
| `kind`, `from`, `to` | yes | See above |
| `declared` | yes | `true` if IaC grants (RBAC) or creates (link, Replicator, connector) this flow |
| `group` | for `consume`, `sink-in` | Consumer group(s). Comma-separate several. Searchable. |
| `mirrorOf` | for `link-out`, `rep-out` | ID of the source topic this destination topic copies. There must be a matching `link-in`/`rep-in` edge from that topic into the same link/Replicator. |
| `bindings` | no | Role bindings that declare the flow: `principal`, `role`, `resource` (e.g. `Topic:orders.v1`, `Group:pay-*`), `source` (IaC file). Shown under "Declared in IaC". |
| `iacSource` | no | For link, Replicator and connector edges: the file that defines them |
| `observed` | no | **Omit entirely if the flow was never observed.** Fields below. |

### observed

| Field | Notes |
|---|---|
| `lastSeenHoursAgo` | Hours between the last observed activity and `generatedAt`. Drives status. |
| `rateMsgs` | Messages per second while active. Drives line thickness and throughput figures. |
| `lag` | Consumer lag, mirror lag or replication lag, in messages. `null` if unknown. |
| `principal` | Principal the traffic was attributed to |
| `state` | Free text such as `ACTIVE` (mirror) or `RUNNING, 4/4 tasks` (connector) |
| `series` | Optional real history for sparklines, keyed by window hours: `{"168": [..values..]}`, oldest first, msg/s. Any number of points (32 works well). Without it, the sparkline shape is illustrative and says so. |

## How statuses are derived

For each edge, given the selected window `W` hours:

```
if not declared                          -> "drift"    (shown as Not in IaC)
else if never observed or lastSeen > W   -> "idle"     (shown as No traffic)
else if lag > settings.lagThreshold      -> "lagging"
else                                     -> "active"
```

An undeclared edge is always drift, whatever the window. It exists only because metrics saw it.

## Derived app-level flows

In Apps only view, the page walks from each application along physical edges through non-application nodes (topics, links, Replicators, connectors) until it reaches another application. Each walk that ends at an app is a **route**; all routes between the same pair of apps form one app-to-app line.

**Links and Replicators preserve topic identity.** A cluster link carries many topics, so a naive walk would go in with `orders.v1` and come out on `payments.v1`'s mirror. When a walk enters a link or Replicator from topic `T`, it only leaves along the `link-out`/`rep-out` edge whose `mirrorOf` is `T`. The same rule applies when tracing upstream. This is why `mirrorOf` is required.

Connectors don't need this rule: a sink connector's only way out is its owning app, and a source connector's only way in is its owning app.

For each app-to-app line:

- **Route status** is its worst step, ranked drift > idle > lagging > active.
- **Line status** is drift if any route is drift. Otherwise it's lagging if any route is lagging, then active if any route is active, then idle.
- **Rate** is the sum of the final step's rate over non-idle routes.
- **Label** is the first topic on its routes, with "+n" for more topics.

## Minimal example

```json
{
  "schemaVersion": 1,
  "generatedAt": "2026-09-27T06:00:00Z",
  "clusters": [ { "id": "c1", "platform": "CC", "name": "prod" } ],
  "apps": [ { "code": "A", "name": "Producer app" }, { "code": "B", "name": "Consumer app" } ],
  "topics": [ { "cluster": "c1", "name": "events" } ],
  "edges": [
    { "kind": "produce", "from": "app:A", "to": "topic:c1:events", "declared": true,
      "observed": { "lastSeenHoursAgo": 0, "rateMsgs": 50 } },
    { "kind": "consume", "from": "topic:c1:events", "to": "app:B", "declared": true, "group": "b-main",
      "observed": { "lastSeenHoursAgo": 0, "rateMsgs": 50, "lag": 12 } }
  ]
}
```

## Compatibility

Unknown fields are ignored by the page and allowed by the schema, so you can carry extra metadata. Edges whose endpoints don't exist are skipped by the page with a console warning, and reported as errors by the validator. A future incompatible change will bump `schemaVersion`.
