# Stream Lineage Explorer

An interactive, single-page lineage map for Kafka estates managed by IaC. It shows how data moves from one application code to another through topics, connectors, Replicator and cluster links, across Confluent Cloud and Confluent Platform clusters. Every flow carries two layers of truth: what your IaC **declares** (topics, RBAC, principals, identity pools, connectors, links) and what your metrics **observe** (produce and consume activity, consumer-group lag, mirror throughput). Where the two disagree, the page flags it.

![Apps-only view focused on ORD](docs/images/apps-view.png)

Version 1.0.0, sample release. The data in `data/` is fictional.

## Quick start

Open `index.html` in a browser. That's it: the libraries are bundled in `vendor/` and the sample graph loads from `data/graph.js`, so it works from disk, offline, with no build step.

To serve it instead (required if you want the page to fetch `data/graph.json` directly):

```bash
make serve            # or: python3 -m http.server 8080
# then open http://localhost:8080/
```

Things to try with the sample data:

- **Search:** type `sa-9zz81k` or `frd-scoring`. Service accounts, identity pools and consumer groups resolve to the app that owns them.
- **Find paths:** from POS to AUD. There are 7 routes, the longest 10 application hops deep.
- **Every hop:** switch from "Apps only" to see each topic, connector, cluster link and Replicator on a route.
- **Needs attention:** the panel on the right lists drift across the whole estate. There are three reads with no IaC grant (one of them by a principal that isn't mapped to any app), one unused grant, and one lagging consumer.
- **Activity window:** set "Activity in last" to 24 hours. RPT's weekly batch then shows as a grant with no traffic.

## How it works

```
 IaC export ─────┐                                   ┌─> data/graph.json ─┐
 (Terraform      │                                   │                    ├─> index.html
  state, app     ├─> tools/build_graph.py ───────────┤                    │   (Cytoscape.js + ELK)
  manifests)     │   joins declared + observed       └─> data/graph.js  ──┘
 metrics export ─┘   tools/validate_graph.py checks it
 (CC Metrics API,
  CP JMX/Admin API)
```

1. A scheduled job exports what your IaC declares and what your metrics observed, in the two formats described in [docs/INTEGRATION.md](docs/INTEGRATION.md). Examples are in `tools/examples/`.
2. `tools/build_graph.py` joins them into one `graph.json`. Each edge records whether it's declared, when it was last seen, its rate and lag, and the role bindings behind it.
3. `tools/validate_graph.py` checks the result against `schema/graph.schema.json` and a set of integrity rules.
4. You publish `index.html`, `vendor/` and `data/` to any static host.

```bash
make build IAC=exports/iac.json METRICS=exports/metrics.json FOCUS=app:ORD
make validate
```

## Package layout

| Path | What it is |
|---|---|
| `index.html` | The whole application: markup, styles and script in one file |
| `vendor/` | Cytoscape.js 3.30.4 (MIT) and elkjs 0.9.3 (EPL-2.0), plus their licenses |
| `data/graph.json` | The sample graph |
| `data/graph.js` | The same graph wrapped as `window.LINEAGE_DATA = …` so the page works from `file://` |
| `schema/graph.schema.json` | JSON Schema for `graph.json` |
| `tools/build_graph.py` | Reference ETL: IaC export + metrics export → `graph.json` (standard library only) |
| `tools/validate_graph.py` | Schema, referential and semantic checks |
| `tools/test_tools.py` | Tests for both tools (`make test`) |
| `tools/examples/` | Example IaC and metrics exports that produce the sample graph |
| `docs/` | Documentation and screenshots |
| `Makefile` | `build`, `validate`, `test`, `serve` |

## Documentation

| Document | Read it when you want to… |
|---|---|
| [User guide](docs/USER_GUIDE.md) | learn every view, control and status on the page |
| [Data model](docs/DATA_MODEL.md) | understand `graph.json`: entity IDs, edge kinds, how statuses and app-level routes are derived |
| [Integration guide](docs/INTEGRATION.md) | feed it real data from Terraform, Confluent Cloud and Confluent Platform |
| [Architecture](docs/ARCHITECTURE.md) | change the code: structure, algorithms, performance, extension points |
| [Deployment](docs/DEPLOYMENT.md) | host it, secure it, automate refreshes, run it offline |
| [Third-party notices](THIRD_PARTY_NOTICES.md) | check the licenses of bundled components |

## Requirements

- **Viewing:** any current Chromium, Firefox or Safari. There's no server-side code.
- **Tools:** Python 3.8 or later. `jsonschema` is optional; `validate_graph.py` runs its own checks without it and adds full schema validation when it's installed.
